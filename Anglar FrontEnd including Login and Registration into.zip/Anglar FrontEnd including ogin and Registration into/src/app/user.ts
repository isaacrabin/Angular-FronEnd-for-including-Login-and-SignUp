export class User {
    id:number;
    firstName:String;
    lastName:String;
    emailId: String;
    password: String;

    constructor(){}
 

    
}
